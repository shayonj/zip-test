# Tines Zip Package Test

This is a test package for the Tines "Bring Your Own Zip" run script functionality.

## Contents

- `bootstrap.sh` - Main bash script that follows the Tines zip package RPC contract
- `run_python.py` - Python version of the script
- `test_with_custom_paths.sh` - Script that uses custom input/output file paths

## Usage in Tines

### Basic Usage
```yaml
Language: Zip Package
Zip URL: https://your-server.com/path/to/tines-test-package.zip
Command: ./bootstrap.sh
Input File: /tmp/tines_input.json
Output File: /tmp/tines_output.json
```

### Python Version
```yaml
Language: Zip Package
Zip URL: https://your-server.com/path/to/tines-test-package.zip
Command: python3 run_python.py
Input File: /tmp/tines_input.json
Output File: /tmp/tines_output.json
```

### Custom Paths
```yaml
Language: Zip Package
Zip URL: https://your-server.com/path/to/tines-test-package.zip
Command: ./test_with_custom_paths.sh
Input File: /custom/input.json
Output File: /custom/output.json
```

## Input Format

The script expects JSON input with the following optional fields:

```json
{
  "name": "Alice",
  "message": "Custom greeting message"
}
```

## Output Format

The script produces JSON output with system information and processing results:

```json
{
  "success": true,
  "message": "Hello from Tines Zip Package!",
  "processed_for": "Alice",
  "timestamp": "2024-01-01T12:00:00Z",
  "system_info": {
    "os": "Linux",
    "architecture": "x86_64",
    "hostname": "lambda-host"
  },
  "execution_details": {
    "working_directory": "/tmp/zip_execution",
    "available_files": ["bootstrap.sh", "run_python.py", "README.md"],
    "environment_vars": {
      "PATH": "/usr/local/bin:/usr/bin:/bin",
      "HOME": "/tmp",
      "USER": "lambda"
    }
  }
}
```

## Testing Locally

You can test the scripts locally:

```bash
# Create test input
echo '{"name": "TestUser", "message": "Local test"}' > /tmp/tines_input.json

# Run bash version
./bootstrap.sh

# Or run Python version
python3 run_python.py

# Check output
cat /tmp/tines_output.json
```
